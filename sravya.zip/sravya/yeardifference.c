#include<stdio.h>
void main()
{
int date1,month1,year1,date2,month2,year2,year_diff,mon_diff,day_diff,mon_count[12]={31,28,31,30,31,30,31,31,30,31,30,31};
printf("Enter date1 : ");
scanf("%d",&date1);
printf("Enter month1 : ");
scanf("%d",&month1);
printf("Enter year1 : ");
scanf("%d",&year1);

printf("Enter date2 : ");
scanf("%d",&date2);
printf("Enter month2 : ");
scanf("%d",&month2);
printf("Enter year2 : ");
scanf("%d",&year2);

//Step 1: Find No of years Differed
year_diff=year2-year1-1;

//Step 2: Find No of Months Differed
mon_diff=((12-(month1))+(month2-1));


//Step 3: Find No of Days Differed
if(month1==2){
	if((year1%4==0 && year1%100!=0) || (year1%400 == 0))
		day_diff=(29-date1)+(date2);
	else
		day_diff=(28-date1)+(date2);
}
else
	day_diff=(mon_count[month1-1]-date1)+(date2);

if(day_diff >=31){
day_diff%=31;
mon_diff+=((day_diff%31)+1);
if(mon_diff>=12)
{
year_diff++;
mon_diff%=12;
}
}
printf("Difference : YEAR : %d, MONTH: %d, DAYs: %d",year_diff,mon_diff,day_diff);
}


