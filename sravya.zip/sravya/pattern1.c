#include<stdio.h>
void main()
{
int n,i,j;
char ch;
printf("Enter a value : ");
scanf("%d",&n);
for(i=1;i<=(n-1);i++)
{
	ch='A';
	for(j=1;j<=i;j++)
	{
		if(j==i)
			printf("%c ",ch++);
		else
			printf("%c* ",ch++);
	}
	printf("\n");
}
}
