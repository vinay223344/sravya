#include<stdio.h>
void main()
{
long int num,digit;
unsigned int c=0;

printf("Enter a number and digit:");
scanf("%ld %ld",&num,&digit);

for(;num!=0;num/=10)
if((num%10)==digit)
c++;
printf("Count : %u",c);
}
