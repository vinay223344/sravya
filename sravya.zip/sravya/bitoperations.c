#include<stdio.h>
#include<stdlib.h>
int set(int n,int pos)
{
return n|(1<<(pos-1));
}

int reset(int n,int pos)
{
return n&(~(1<<(pos-1)));
}

int toggle(int n,int pos)
{
return n^(1<<(pos-1));
}

void main(){
int n1,n2,pos,ch;

while(1)
{
printf("Enter your choice : \n1. set\n2. clear\n3. Toggle\n4. Swap\n5. Exit\n");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("Enter a Number & Position : ");
	scanf("%d %d",&n1,&pos);
	printf("%d\n",set(n1,pos));
	break;
case 2:printf("Enter a Number & Position : ");
	scanf("%d %d",&n1,&pos);
	printf("%d\n",reset(n1,pos));
	break;
case 3:printf("Enter a Number & Position : ");
	scanf("%d %d",&n1,&pos);
	printf("%d\n",toggle(n1,pos));
	break;
case 4:printf("Enter a Number1 & Number2 : ");
	scanf("%d %d",&n1,&n2);
	printf("Before : n1 = %d , n2 = %d\n",n1,n2);
	n1=n1^n2;
	n2=n1^n2;
	n1=n1^n2;
	printf("Before : n1 = %d , n2 = %d\n",n1,n2);
	break;
case 5:printf("Terminating Successfully!!");
	exit(1);
default:printf("Enter correct choice");
}

}
}
