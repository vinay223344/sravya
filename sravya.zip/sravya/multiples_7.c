#include<stdio.h>
void main()
{
int i=1;
Multiple:
if(i<=500)
{
	if(i%7 == 0) printf("%d ",i);
	i++;
	goto Multiple;
}
}
