#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
char dob[11],mon[4];
int date=0,year=0,i,y1,y2,sum=0,ly,nly,res2,arr[12]={0,3,3,6,1,4,6,2,5,0,3,5};
char day[7][10]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
printf("Enter date of birth : ");
scanf("%s",dob);

for(i=0;i<2;i++)
date=(dob[i]-'0')+date*10;

for(i=3;i<6;i++)
mon[i-3]=dob[i];

for(i=7;i<11;i++)
year=(dob[i]-'0')+year*10;

//STAGE - 1
//Step -1: Year to nearer century year
y1=year-1;
ly=(y1/4)*2;
//nly=y1-(y1/4);
nly=(y1>(y1/4))?(y1-(y1/4)):((y1/4)-y1);
sum+=(ly+nly);
mon[3]='\0';

//step-3 : Month Comparision - arr(consists of no of odd days until before month) + no of days in current month

if(strcmp(mon,"Jan")==0)
sum+=arr[0]+date;
else if(strcmp(mon,"Feb")==0)
sum+=arr[1]+date;
else if(strcmp(mon,"Mar")==0)
sum+=arr[2]+date;
else if(strcmp(mon,"Apr")==0)
sum+=(arr[3]+date);
else if(strcmp(mon,"May")==0)
sum+=arr[4]+date;
else if(strcmp(mon,"Jun")==0)
sum+=arr[5]+date;
else if(strcmp(mon,"Jul")==0)
sum+=arr[6]+date;
else if(strcmp(mon,"Aug")==0)
sum+=arr[7]+date;
else if(strcmp(mon,"Sep")==0)
sum+=arr[8]+date;
else if(strcmp(mon,"Oct")==0)
sum+=arr[9]+date;
else if(strcmp(mon,"Nov")==0)
sum+=arr[10]+date;
else if(strcmp(mon,"Dec")==0)
sum+=arr[11]+date;

if((year%4==0 && year%100!=0) || (year%400 == 0))
printf("%s",day[(sum%7)]);
else
printf("%s",day[(sum%7)-1]);

return 0;
}

